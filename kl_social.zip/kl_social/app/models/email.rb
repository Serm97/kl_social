class Email < ApplicationRecord
  belongs_to :user
end
