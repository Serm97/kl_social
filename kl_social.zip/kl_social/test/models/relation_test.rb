require 'test_helper'

class RelationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
