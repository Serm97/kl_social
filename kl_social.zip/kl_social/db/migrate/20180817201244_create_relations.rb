class CreateRelations < ActiveRecord::Migration[5.2]
  def change
    create_table :relations do |t|
      t.references :user, foreign_key: true
      t.integer :user_invited
      t.boolean :visible_name
      t.boolean :visible_lastname
      t.boolean :visible_dateborn
      t.boolean :visible_phone
      t.boolean :visible_mail

      t.timestamps
    end
  end
end
